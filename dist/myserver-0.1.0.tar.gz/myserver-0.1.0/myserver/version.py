version_info = (0, 1, 0)
__version__ = ".".join([str(v) for v in version_info])
SERVER_SOFTWARE = "myserver/%s" % __version__