__version__ = '0.1.0'


bind = '127.0.0.1:8080'
conf = 'default'
debug = False
param = {}
plugin = ''
reload = False
server = 'myserver'
version = __version__
reloader = 'auto'
